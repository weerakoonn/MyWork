# one-page-website-html-css-project-for-practice
This project is for html &amp; css practice. We made this for youtube tutorial purpose.

Watch The Complete Tutorial : https://youtu.be/ZFQkb26UD1Y
